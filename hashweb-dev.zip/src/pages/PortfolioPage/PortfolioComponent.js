import React from 'react';
import styled from 'styled-components';
import { motion } from 'framer-motion';

const Container = styled.section`
  margin: 1.5rem auto;
  text-align: center;
  overflow: hidden;
  h1 {
    font-size: 2rem;
    margin-bottom: 2rem;
    color: #fff;
  }

  @media (max-width: 520px) {
    margin: 0 auto;
    h1 {
      margin-top: 0;
    }
  }
`;

const CardContainer = styled.div`
  display: flex;
  justify-content: center;
  flex-wrap: wrap;
`;

const Card = styled.div`
  height: 250px;
  width: 250px;
  background-color: rgba(0, 0, 0, 0.2);
  margin-left: 2rem;
  border-radius: 10px;

  @media (max-width: 500px) {
    margin-left: 0;
    margin-bottom: 1rem;
  }
`;

const Footer = styled(motion.div)`
  color: #bdc3c7;
  line-height: 1.8;
  word-space: 1.2;
  letter-spacing: 1px;
  margin-top: 5rem;
  h5 {
    font-size: 1rem;
    margin-bottom: 0rem;
  }
  p {
    font-size: 0.8rem;
    margin-top: 0.5rem;
  }

  strong {
    cursor: pointer;
  }

  @media (max-width: 520px) {
    h5 {
      font-size: 0.9rem;
    }
    p {
      font-size: 0.6rem;
    }
  }
`;

const sectionVariant = {
  initial: {
    x: '100vw',
    opacity: 0,
  },
  animate: {
    x: 0,
    opacity: 1,
    transition: {
      duration: 1,
      type: 'spring',
      stiffness: 110,
    },
  },
};

const footerVariant = {
  initial: {
    opacity: 0,
  },
  animate: {
    opacity: 1,
    transition: {
      delay: 2,
      duration: 1,
      ease: 'easeInOut',
    },
  },
};

const PortfolioComponent = () => {
  return (
    <Container>
      <motion.div variants={sectionVariant} initial='initial' animate='animate'>
        <h1>Portfolio</h1>
        <CardContainer>
          <Card>sadasd</Card>
          <Card>asdasd</Card>
        </CardContainer>
      </motion.div>
      <Footer variants={footerVariant} initial='initial' animate='animate'>
        <h5>Let's talk</h5>
        <p>
          Wanna get in touch or talk about a project? <br />
          Feel free to contact me via email at <strong>jagadeesh@hashweb.dev</strong> <br />
          or drop a line in the form at the <strong>contact page</strong>
        </p>
      </Footer>
    </Container>
  );
};

export default PortfolioComponent;
